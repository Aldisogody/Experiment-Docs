import { expect, test } from '@playwright/test';
import { buttonText } from '../src/config.js';
import { urlsConfig } from './config.js';
import { experimentContainer, setupPage, takeScreenshot } from './helpers.js';

for (const market of urlsConfig.markets) {
    test.describe(`ExperimentButton [${market.code}]`, () => {
        test('renders the experiment button with correct text', async ({ page }, testInfo) => {
            await setupPage(page, market, testInfo);
            const container = page.locator(experimentContainer);

            await expect(container).toBeVisible();
            await expect(container.locator('button')).toBeVisible();
            await expect(container.locator('button')).toContainText(buttonText);

            await takeScreenshot(page, market.code, 'experiment-button', testInfo);
        });
    });
}
