import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { selectors } from '../src/config.js';
import { urlsConfig } from './config.js';

const primarySelector = selectors.primary;

function loadBundle(bundlePath) {
    const abs = resolve(bundlePath);
    if (!existsSync(abs)) {
        throw new Error(
            `IIFE bundle not found at "${abs}".\nRun E2E tests through "pnpm test:e2e" so the bundle is built first.`,
        );
    }
    return readFileSync(abs, 'utf-8');
}

export const iifeBundle = loadBundle(urlsConfig.bundlePath);

/** v1 mounts as the first child of the injection target. */
export const experimentContainer = `${primarySelector} > div:first-child`;

/**
 * Inject the target element that the experiment expects on the page.
 * Only supports simple class selectors (e.g. `.my-class`).
 */
export async function injectTargetElement(page) {
    if (!primarySelector.startsWith('.') || primarySelector.includes(' ')) {
        throw new Error(
            `injectTargetElement: unsupported selector "${primarySelector}" — only simple class selectors are supported`,
        );
    }
    await page.evaluate((selector) => {
        if (!document.querySelector(selector)) {
            const el = document.createElement('div');
            el.className = selector.replace(/^\./, '');
            document.body.appendChild(el);
        }
    }, primarySelector);
}

/**
 * Take a named screenshot for visual regression of the experiment component.
 * Attaches to Playwright test report for viewing in the HTML reporter.
 */
export async function takeScreenshot(page, marketCode, name, testInfo) {
    const container = page.locator(experimentContainer);
    const screenshot = await container.screenshot();
    await testInfo.attach(`${marketCode}-${name}`, {
        body: screenshot,
        contentType: 'image/png',
    });
}

/**
 * Combined page setup: navigate → inject target → add IIFE bundle → wait for experiment → attach URL.
 * After this resolves, `experimentContainer` is guaranteed to be present on the page.
 */
export async function setupPage(page, market, testInfo) {
    const testUrl = urlsConfig.getUrl(market.code, '/');
    await page.goto(testUrl);
    await injectTargetElement(page);
    await page.addScriptTag({ content: iifeBundle });
    await page.locator(experimentContainer).waitFor();

    await testInfo.attach('Test Page URL', {
        body: testUrl,
        contentType: 'text/plain',
    });
}
