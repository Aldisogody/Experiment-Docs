# Generator

node-plop generator that receives CLI answers and scaffolds the project.

## Entry Point

`index.js` — exports a plop generator named `experiment`

## How It Works

`lib/scaffold-plan.js` is the source of truth for what gets generated. It emits file-oriented scaffold steps, and `generator/actions.js` translates those steps into Plop actions.

1. **`base-hbs`** — glob `template/**/*.hbs`, excluding e2e templates and boilerplate-specific overrides
2. **`base-static`** — copy `.scss`, `.nvmrc`, and optional base `src/helpers.js`
3. **`rename-dot-files`** — recursively rename `dot.*` → `.*` in target dir
4. **`overlay-hbs` / `overlay-static` / `overlay-claude`** — minimal boilerplate overlay steps
5. **`e2e-*`** — Playwright config, smoke test, URL config, and helpers when `useE2ETesting` is true
6. **`variation`** — additional `v2..vN` entry files

Do not add parallel action-builder functions for new template behavior. Extend the scaffold plan first, then update the Plop action adapter.

## Answers Shape

```js
{ targetDir, experimentName, globalObject, classPrefix, includeEmergencyBrake, useE2ETesting, baseUrl, market, markets, marketUrlPath, runSmokeTest, boilerplateType, variationCount }
```

- `targetDir` — absolute path to output directory
- `experimentName` — project name (from CLI arg, used in package.json and config)
- `globalObject` — JS identifier for window namespace (default: `sgd`)
- `classPrefix` — sanitized CSS Modules class prefix derived from `experimentName` via `lib/sanitize.js`; computed in the generator's `actions()` function (not passed from CLI)
- `includeEmergencyBrake` — boolean for Adobe Target emergency brake
- `useE2ETesting` — boolean, enables Playwright e2e file generation
- `baseUrl` — target site URL for e2e tests (when e2e enabled). Resolved in `actions()` via `lib/e2e.js#resolveE2eBaseUrl`: when `useE2ETesting` is true and the value is empty/whitespace, it defaults to `https://samsung.com`
- `market` — market code key (when e2e enabled)
- `markets` — resolved market objects from `lib/markets.js`
- `marketUrlPath` — URL path segment for the selected market
- `runSmokeTest` — boolean, runs smoke test after generation (when e2e enabled)
- `boilerplateType` — `'product-card'` or `'minimal'` (default); controls which template overlay is used
- `variationCount` — number of variations to generate (default: 1); generates `v2..vN` via a post-action loop

## Custom Action Types

- `renameDotFiles` — recursively walks `targetDir` and renames every `dot.*` file to `.*`
- `addVariation` — renders a variation template with a caller-supplied `variationName`, bypassing plop's answer-merge limitation that would always use the top-level `variationName` from `answers`

## Custom Helpers

- `json` — `JSON.stringify(value)` for rendering booleans correctly in HBS

## Rules

- Prompts array is empty — all answers come from `cli.js` via `runActions()`
- Adding new template files: use `.hbs` extension if they need interpolation
- Adding new static files: add the file to the scaffold plan's relevant step, then translate that step in `generator/actions.js`
- New dot-files: prefix with `dot.` (e.g., `dot.prettierrc`) — `renameDotFiles` handles the rest
- New e2e files: add an `e2e-*` scaffold step gated by `useE2ETesting`
- `live` script is always generated as `exp-live`; the live runner belongs to the package, not generated project files.
- Both `product-card` and `minimal` boilerplates share `template/` HBS files; minimal overrides `src/config.js`, `src/js/v1/index.jsx`, and `src/components/` via overlay actions
