import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { renameSync, readdirSync, statSync, readFileSync, mkdirSync, writeFileSync } from 'node:fs';
import { validateAnswers } from '../lib/answers.js';
import { buildActions } from './actions.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const TEMPLATE_DIR = join(__dirname, '../template');
const MINIMAL_TEMPLATE_DIR = join(__dirname, '../template-minimal');
const PACKAGE_JSON = JSON.parse(readFileSync(join(__dirname, '../package.json'), 'utf-8'));
const CREATE_EXPERIMENT_VERSION = `^${PACKAGE_JSON.version}`;
const DIRS = { templateDir: TEMPLATE_DIR, minimalTemplateDir: MINIMAL_TEMPLATE_DIR };

/**
 * Recursively rename `dot.*` files to `.*` files inside a directory.
 */
function renameDotFiles(dir) {
    for (const entry of readdirSync(dir)) {
        const fullPath = resolve(dir, entry);
        if (statSync(fullPath).isDirectory()) {
            renameDotFiles(fullPath);
        } else if (entry.startsWith('dot.')) {
            const newName = `.${entry.slice(4)}`;
            renameSync(fullPath, resolve(dir, newName));
        }
    }
}

export default function (plop) {
    // Helper: render boolean values correctly (not as strings)
    plop.setHelper('json', (value) => JSON.stringify(value));
    plop.setHelper('eq', (left, right) => left === right);

    // Custom action: rename dot.* → .* in the target directory
    plop.setActionType('renameDotFiles', async (answers) => {
        renameDotFiles(answers.targetDir);
        return 'dot.* files renamed to .*';
    });

    // Custom action: render a variation template with an overridden variationName.
    // Needed because plop merges data as Object.assign({}, cfg.data, answers), so answers
    // always win — we can't override variationName via the standard add action's data option.
    plop.setActionType('addVariation', async (answers, config, plop) => {
        const rendered = plop.renderString(
            readFileSync(config.templateFile, 'utf-8'),
            { ...answers, variationName: config.variationName },
        );
        mkdirSync(dirname(config.dest), { recursive: true });
        writeFileSync(config.dest, rendered, 'utf-8');
        return `Created ${config.dest}`;
    });

    plop.setGenerator('experiment', {
        description: 'Scaffold a new A/B experiment project',
        prompts: [], // Prompts handled by cli.js; answers injected via runActions()
        actions(data) {
            validateAnswers(data);
            data.createExperimentVersion = CREATE_EXPERIMENT_VERSION;
            return buildActions(data, DIRS);
        },
    });
}
