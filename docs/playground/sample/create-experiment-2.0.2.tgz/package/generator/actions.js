import { join } from 'node:path';
import { buildScaffoldPlan } from '../lib/scaffold-plan.js';

function toPlopAction(step, data, dirs) {
    if (step.kind === 'base-hbs') {
        const hbsIgnore = [
            `${dirs.templateDir}/playwright.config.js.hbs`,
            `${dirs.templateDir}/e2e/**/*.hbs`,
            ...step.excludedTemplates.map((pattern) => `${dirs.templateDir}/${pattern}`),
            ...step.boilerplate.baseTemplateIgnores.map((pattern) => `${dirs.templateDir}/${pattern}`),
        ];
        return {
            type: 'addMany',
            destination: data.targetDir,
            base: dirs.templateDir,
            templateFiles: `${dirs.templateDir}/**/*.hbs`,
            globOptions: { dot: true, ignore: hbsIgnore },
            stripExtensions: ['hbs'],
        };
    }

    if (step.kind === 'base-static') {
        return {
            type: 'addMany',
            destination: data.targetDir,
            base: dirs.templateDir,
            templateFiles: [
                `${dirs.templateDir}/**/*.scss`,
                ...(step.boilerplate.copiesBaseHelpers ? [`${dirs.templateDir}/src/helpers.js`] : []),
                `${dirs.templateDir}/dot.nvmrc`,
            ],
            globOptions: {
                dot: true,
                ignore: step.boilerplate.staticBaseIgnores.map((pattern) => `${dirs.templateDir}/${pattern}`),
            },
        };
    }

    if (step.kind === 'rename-dot-files') {
        return { type: 'renameDotFiles' };
    }

    if (step.kind === 'overlay-hbs') {
        return {
            type: 'addMany',
            destination: join(data.targetDir, 'src'),
            base: join(step.templateDir, 'src'),
            templateFiles: `${step.templateDir}/src/**/*.hbs`,
            stripExtensions: ['hbs'],
        };
    }

    if (step.kind === 'overlay-static') {
        return {
            type: 'addMany',
            destination: join(data.targetDir, 'src'),
            base: join(step.templateDir, 'src'),
            templateFiles: [
                `${step.templateDir}/src/**/*.scss`,
            ],
        };
    }

    if (step.kind === 'e2e-config') {
        return { type: 'add', path: join(data.targetDir, 'playwright.config.js'), templateFile: step.templateFile };
    }

    if (step.kind === 'e2e-smoke') {
        return { type: 'add', path: join(data.targetDir, 'e2e/smoke.spec.js'), templateFile: step.templateFile };
    }

    if (step.kind === 'e2e-url-config') {
        return { type: 'add', path: join(data.targetDir, 'e2e/config.js'), templateFile: step.templateFile };
    }

    if (step.kind === 'e2e-helpers') {
        return { type: 'add', path: join(data.targetDir, 'e2e/helpers.js'), templateFile: step.templateFile };
    }

    if (step.kind === 'variation') {
        return {
            type: 'addVariation',
            variationName: step.variationName,
            templateFile: step.templateFile,
            dest: step.dest,
        };
    }

    if (step.kind === 'variation-style') {
        return { type: 'add', path: step.dest, templateFile: step.templateFile };
    }

    throw new Error(`Unknown scaffold step "${step.kind}"`);
}

export function buildActions(data, dirs) {
    return buildScaffoldPlan(data, dirs).map((step) => toPlopAction(step, data, dirs));
}
