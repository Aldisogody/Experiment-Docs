const BOILERPLATES = {
    minimal: {
        type: 'minimal',
        overlayRoot: 'template-minimal',
        e2eTemplateRoot: 'template-minimal',
        baseTemplateIgnores: [
            'src/config.js.hbs',
            'src/js/v1/index.jsx.hbs',
            'src/components/**',
        ],
        staticBaseIgnores: ['src/components/**', 'src/js/**'],
        copiesBaseHelpers: false,
        variationCopiesStyles: false,
    },
    'product-card': {
        type: 'product-card',
        overlayRoot: null,
        e2eTemplateRoot: 'template',
        baseTemplateIgnores: [],
        staticBaseIgnores: [],
        copiesBaseHelpers: true,
        variationCopiesStyles: false,
    },
};

export function listBoilerplateTypes() {
    return Object.keys(BOILERPLATES);
}

export function getBoilerplateDefinition(type = 'product-card') {
    const definition = BOILERPLATES[type];
    if (!definition) {
        throw new Error(`Unknown boilerplateType "${type}"`);
    }
    return definition;
}

export function resolveTemplateRoot(definition, dirs) {
    return definition.overlayRoot === 'template-minimal' ? dirs.minimalTemplateDir : dirs.templateDir;
}
