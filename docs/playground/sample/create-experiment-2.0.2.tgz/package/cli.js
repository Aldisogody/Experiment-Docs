#!/usr/bin/env node
import * as clack from '@clack/prompts';
import { spawn } from 'node:child_process';
import nodePlop from 'node-plop';
import { existsSync, readdirSync } from 'node:fs';
import { resolve, basename, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildGeneratorAnswers } from './lib/cli-session.js';
import { getMarketChoices } from './lib/markets.js';
import { buildPostGenSteps } from './lib/post-gen.js';
import { DEFAULT_E2E_BASE_URL, validateE2eBaseUrlInput } from './lib/e2e.js';

const __dirname = dirname(fileURLToPath(import.meta.url));

function runSpawnWithSpinner(spinner, args, cwd, successMsg, failMsg) {
    return new Promise((resolve) => {
        const proc = spawn('pnpm', args, { cwd, stdio: 'pipe' });
        proc.on('close', (code) => {
            const ok = code === 0;
            spinner.stop(ok ? successMsg : failMsg);
            resolve(ok);
        });
        proc.on('error', () => {
            spinner.stop(failMsg);
            resolve(false);
        });
    });
}

async function main() {
    const targetArg = process.argv[2];

    if (!targetArg) {
        console.error('Usage: create-experiment <project-name>');
        console.error('Example: npx create-experiment my-experiment');
        process.exit(1);
    }

    const targetDir = resolve(process.cwd(), targetArg);
    const experimentName = basename(targetDir);

    // Warn if directory exists and is non-empty
    if (existsSync(targetDir) && readdirSync(targetDir).length > 0) {
        const overwrite = await clack.confirm({
            message: `Directory "${experimentName}" already exists and is not empty. Continue anyway?`,
            initialValue: false,
        });
        if (!overwrite || clack.isCancel(overwrite)) {
            clack.cancel('Aborted.');
            process.exit(0);
        }
    }

    clack.intro(`create-experiment v2`);

    const answers = await clack.group(
        {
            boilerplateType: () =>
                clack.select({
                    message: 'Select boilerplate',
                    options: [
                        { value: 'minimal', label: 'Minimal Button', hint: 'Simple locale-aware button, no API' },
                        { value: 'product-card', label: 'Product Upsell Card', hint: 'Samsung product card with API fetch' },
                    ],
                    initialValue: 'minimal',
                }),

            variationCount: () =>
                clack.select({
                    message: 'Number of variations',
                    options: [
                        { value: 1, label: '1' },
                        { value: 2, label: '2  (A/B)' },
                        { value: 3, label: '3  (A/B/C)' },
                        { value: 4, label: '4' },
                        { value: 'custom', label: 'Custom...' },
                    ],
                    initialValue: 1,
                }),

            variationCountCustom: ({ results }) =>
                results.variationCount === 'custom'
                    ? clack.text({
                        message: 'How many variations?',
                        validate: (v) => {
                            const n = parseInt(v, 10);
                            if (Number.isNaN(n) || n < 1 || n > 10) return 'Enter a number between 1 and 10';
                        },
                    })
                    : undefined,

            globalObject: () =>
                clack.text({
                    message: 'Window namespace to register the experiment under',
                    placeholder: 'sgd',
                    defaultValue: 'sgd',
                    validate(value) {
                        const id = value || 'sgd';
                        if (!/^[a-zA-Z_$][a-zA-Z0-9_$]*$/.test(id)) {
                            return 'Must be a valid JavaScript identifier (letters, digits, _, $)';
                        }
                    },
                }),

            includeEmergencyBrake: () =>
                clack.confirm({
                    message: 'Enable the emergency brake feature (Adobe Target)?',
                    initialValue: true,
                }),

            useE2ETesting: () =>
                clack.confirm({
                    message: 'Do you want to use e2e testing?',
                    initialValue: false,
                }),

            baseUrl: ({ results }) =>
                results.useE2ETesting
                    ? clack.text({
                        message: 'Base URL for tests',
                        placeholder: DEFAULT_E2E_BASE_URL,
                        defaultValue: DEFAULT_E2E_BASE_URL,
                        validate: validateE2eBaseUrlInput,
                    })
                    : undefined,

            market: ({ results }) =>
                results.useE2ETesting
                    ? clack.select({ message: 'Market code', options: getMarketChoices() })
                    : undefined,

            runSmokeTest: ({ results }) =>
                results.useE2ETesting
                    ? clack.confirm({ message: 'Do you want to run a smoke test?' })
                    : undefined,
        },
        {
            onCancel() {
                clack.cancel('Operation cancelled.');
                process.exit(0);
            },
        },
    );

    const finalAnswers = buildGeneratorAnswers({
        targetDir,
        experimentName,
        boilerplateType: answers.boilerplateType,
        variationCount: answers.variationCount,
        variationCountCustom: answers.variationCountCustom,
        globalObject: answers.globalObject,
        includeEmergencyBrake: answers.includeEmergencyBrake,
        useE2ETesting: answers.useE2ETesting,
        baseUrl: answers.baseUrl,
        market: answers.market,
        runSmokeTest: answers.runSmokeTest,
    });

    const s = clack.spinner();
    s.start('Generating project files...');

    try {
        const plop = await nodePlop(resolve(__dirname, 'generator/index.js'));
        const generator = plop.getGenerator('experiment');
        const result = await generator.runActions(finalAnswers);

        if (result.failures.length > 0) {
            s.stop('Generation failed.');
            for (const failure of result.failures) {
                console.error(failure.error || failure.message);
            }
            process.exit(1);
        }

        s.stop('Project files created.');
    } catch (err) {
        s.stop('Generation failed.');
        console.error(err.message);
        process.exit(1);
    }

    const postGenSteps = buildPostGenSteps(finalAnswers);

    for (const step of postGenSteps) {
        if (!step.when()) continue;
        const spinner = clack.spinner();
        spinner.start(step.start);
        const ok = await runSpawnWithSpinner(spinner, step.args, targetDir, step.ok, step.fail);
        if (!ok) break;
    }

    const e2eInstructions = finalAnswers.useE2ETesting
        ? `  pnpm test:e2e           → run Playwright tests\n`
        : '';

    clack.outro(
        `Ready! Your experiment is at ./${experimentName}\n\n` +
        `  cd ${experimentName}\n` +
        `  pnpm start 0           → watch v1, copy to clipboard on save\n` +
        `  pnpm build             → production IIFE bundles\n` +
        `  pnpm lint              → Biome check\n` +
        e2eInstructions,
    );
}

main();
