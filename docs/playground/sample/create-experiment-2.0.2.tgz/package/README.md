# create-experiment

CLI that scaffolds a Vite + Preact A/B experiment project for Adobe Target. Generates a self-contained IIFE bundle per variation, wired up with `create-experiment/framework`, with clipboard copy on save so the built code can be pasted directly into Adobe Target.

## Prerequisites

- Node ≥ 20.19 (recommended: 24 — see `.nvmrc`)
- pnpm 10.30.1

## Usage

```bash
npx create-experiment <project-name>
```

**Prompts:**

| Prompt | Default | Notes |
|--------|---------|-------|
| Boilerplate type | `minimal` | `minimal` (generic button UI) or `product-card` (Samsung product card UI) |
| Window namespace | `sgd` | JS identifier registered on `window` (e.g. `window.sgd`) |
| Emergency brake | `true` | Enables Adobe Target kill-switch via `experiment.config.js` |
| Variation count | `1` | Number of variations to scaffold (v1..vN) |
| E2E testing | `false` | Generates Playwright smoke tests when enabled |

After scaffolding, dependencies are installed automatically.

## What gets generated

**Minimal boilerplate** (default — generic button UI):

```
<project-name>/
  src/
    components/
      ExperimentButton/     # Locale-aware button component
        index.jsx
        styles.module.scss
    js/
      v1/                   # Variation 1 entry point
        index.jsx           # runScript → render → track
      v2/                   # Additional variations (when variationCount > 1)
    config.js               # selectors, buttonText
  # Runtime/build/new-variation tooling is provided by
  # create-experiment dependency via exp-* binaries
  experiment.config.js      # runtime globalObject, emergencyBrake, targetUrl
  vite.config.js            # IIFE lib mode, Preact bundled, legacy aliases, CSS Modules
  biome.json                # JS/JSX formatter + linter
```

**Product-card boilerplate** (Samsung product card with API fetch):

```
<project-name>/
  src/
    components/
      ExperimentCard/       # Product card Preact component
        index.jsx
        styles.module.scss
    js/
      v1/
        index.jsx           # runScript → fetch → render → track
    config.js               # selectors, MODEL_CODE_MAP, translations
    helpers.js              # Samsung API fetch, formatPrice, modelCode
  ...                       # (same dependency-provided tooling and config files as above)
```

## Dev workflow

```bash
pnpm start 0        # watch v1 — rebuilds on save, copies bundle to clipboard
pnpm dev            # watch all variations
pnpm build          # production IIFE bundles → dist/vN-index.jsx
pnpm live           # runs package-owned exp-live; opens targetUrl and injects the watched variation
pnpm live -- --profile shared  # reuse one OS cache profile across experiments
pnpm init-claude    # create CLAUDE.md on demand
pnpm init-agents    # create AGENTS.md on demand
pnpm lint           # Biome for JS/JSX/JSON
```

The `-e0` flag maps to `src/js/v1/index.jsx`, `-e1` to `v2`, and so on. The clipboard copy lets you paste the bundle straight into Adobe Target's custom code editor. Production output uses the legacy flat shape, for example `dist/v1-index.jsx`.

CSS Modules class prefix is auto-derived from the project folder name (sanitized), so no extra CLI prompt is required. Generated class names use the legacy separator, for example `project-name--button`.

CSS is compiled by Vite with Sass support. Generated projects do not include Stylelint or cssnano; production CSS minification uses Vite's built-in esbuild CSS minifier.

Generated Vite config includes legacy import aliases: `@src`, `@js`, `@components`, `@services`, and `@helpers`. Build and live commands read `experiment.config.js` first and fall back to legacy `config.json`.

Runtime helpers from `create-experiment/framework` include legacy-compatible exports such as `runScript`, `withPreact`, `waitForJquery`, `domReady`, `createElementFromHTML`, `setCookie`, `getCookie`, `emergencyBrakeEnabled`, and `classes`. `withPreact` is a compatibility shim because Preact remains bundled.

AI documentation is opt-in. The init commands infer the generated boilerplate and E2E setup,
and refuse to overwrite existing files unless passed `-- --force`.
After upgrading `create-experiment` in an older generated project, run the binaries directly
with `pnpm exec exp-init-claude` or `pnpm exec exp-init-agents`.

## Adding a variation

```bash
pnpm new-variation 2    # scaffolds src/js/v2/ from v1
```

Then update selectors, props, and tracking label in `src/js/v2/index.jsx` and run `pnpm build`.

## Tracking

Use `setupTracking` after Preact render so the rendered element exists. For the
product-card scaffold, it defaults to `selector: 'a'`, `eVar26`, and `event26`,
so only a label is required:

```js
setupTracking(container, { label: 'experiment-name: v1 cta clicked' });
```

## CI

No CI pipeline is configured yet. Run `pnpm test` locally before opening a PR.

## Contributing

```bash
nvm use 24            # match .nvmrc
pnpm install
pnpm test             # run integration tests before committing
```

## Migration Note

If you generated a project with older package conventions, replace these script names in your generated project:

- `sogody-start` -> `exp-start`
- `sogody-build` -> `exp-build`
- `sogody-new-variation` -> `exp-new-variation`
