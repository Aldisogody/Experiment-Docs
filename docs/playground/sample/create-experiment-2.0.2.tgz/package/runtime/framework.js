// framework.js — experiment runtime helpers

const getDefinedValue = (identifierValue, globalKey, fallback) => {
	if (typeof identifierValue === 'string') return identifierValue;
	if (
		typeof globalThis !== 'undefined' &&
		typeof globalThis[globalKey] === 'string'
	)
		return globalThis[globalKey];
	return fallback;
};

const getPackageName = () =>
	getDefinedValue(
		typeof __packageName__ === 'string' ? __packageName__ : undefined,
		'__packageName__',
		'create-experiment',
	);
const getBuildEnv = () =>
	getDefinedValue(
		typeof __buildEnv__ === 'string' ? __buildEnv__ : undefined,
		'__buildEnv__',
		'production',
	);
const getGlobalObjectName = () =>
	getDefinedValue(
		typeof __globalObject__ === 'string' ? __globalObject__ : undefined,
		'__globalObject__',
		'sgd',
	);
const getIncludeEmergencyBrake = () =>
	getDefinedValue(
		typeof __includeEmergencyBrake__ === 'string'
			? __includeEmergencyBrake__
			: undefined,
		'__includeEmergencyBrake__',
		'false',
	) === 'true';
const getEmergencyBrakeConfig = () =>
	getDefinedValue(
		typeof __emergencyBrakeConfig__ === 'string'
			? __emergencyBrakeConfig__
			: undefined,
		'__emergencyBrakeConfig__',
		// eslint-disable-next-line no-template-curly-in-string
		'${user.sgdEmergencyBrake}',
	);

const getGlobalObject = () => {
	const root = typeof window !== 'undefined' ? window : globalThis;
	const globalObjectName = getGlobalObjectName();
	root[globalObjectName] = root[globalObjectName] || {};
	return root[globalObjectName];
};

const debugFromQueryString = () => {
	if (typeof window === 'undefined') return false;
	return (
		new URLSearchParams(window.location?.search || '').get('expDebug') === '1'
	);
};

const debugFromLocalStorage = () => {
	try {
		if (typeof window === 'undefined' || !window.localStorage) return false;
		return window.localStorage.getItem('expDebug') === '1';
	} catch {
		return false;
	}
};

const writeLog = (args) => {
	if (typeof console === 'undefined') return;
	console.log.apply(null, [getPackageName()].concat(args));
};

export const log = (...args) => {
	if (getBuildEnv() === 'development') {
		writeLog(args);
	}
};

export const debug = (...args) => {
	if (debugFromQueryString() || debugFromLocalStorage()) {
		writeLog(args);
	}
};

/**
 * Returns the current browser path, including query string and hash.
 * @returns {string}
 */
export const getPath = () => {
	if (typeof window === 'undefined') return '';
	const { pathname, search, hash } = window.location;
	return `${pathname}${search}${hash}`;
};

/**
 * Splits a path into raw non-empty pathname segments.
 * Query string and hash are ignored.
 * @param {string} [path]
 * @returns {string[]}
 */
export const getPathSegments = (path = getPath()) =>
	path.split(/[?#]/)[0].split('/').filter(Boolean);

/**
 * Returns the lowercase market segment from a path.
 * @param {string} [path]
 * @returns {string|null}
 */
export const getMarket = (path = getPath()) =>
	getPathSegments(path)[0]?.toLowerCase() ?? null;

export const getScript = (source, callback) => {
	const script = document.createElement('script');
	const prior = document.getElementsByTagName('script')[0];
	script.async = 1;
	script.onload = script.onreadystatechange = function onScriptLoad(
		_,
		isAbort,
	) {
		if (
			isAbort ||
			!script.readyState ||
			/loaded|complete/.test(script.readyState)
		) {
			script.onload = null;
			script.onreadystatechange = null;
			if (!isAbort && callback) setTimeout(callback, 0);
		}
	};
	script.src = source;
	prior.parentNode.insertBefore(script, prior);
};

export const withPreact = (callback) => callback();

export const waitForJquery = (callback) => {
	const interval = setInterval(
		(function intv() {
			if (typeof window !== 'undefined' && window.$) {
				callback();
				clearInterval(interval);
			}

			return intv;
		})(),
		50,
	);
};

export const domReady = (callback) => {
	if (document.readyState !== 'loading') {
		callback();
	} else if (document.addEventListener) {
		document.addEventListener('DOMContentLoaded', callback);
	} else {
		document.attachEvent('onreadystatechange', () => {
			if (document.readyState !== 'loading') callback();
		});
	}
};

/**
 * Runs script bound to the configured global object.
 * @param {Function} fn - function containing the experiment logic
 * @param {boolean} singleInstance - whether only one instance should run
 * @param {boolean} waitDomReady - whether to wait for DOM readiness
 */
export const runScript = (fn, singleInstance = false, waitDomReady = true) => {
	const name = getPackageName();
	const run = () => {
		const globalObject = getGlobalObject();

		if (getIncludeEmergencyBrake() && emergencyBrakeEnabled()) {
			globalObject[name] = `${name}-disabled`;
			return;
		}

		if (!globalObject[name] || !singleInstance) {
			globalObject[name] = fn;
			globalObject[name]();
		}
	};

	if (waitDomReady) {
		domReady(run);
	} else {
		run();
	}
};

const POSITIONS = ['beforebegin', 'afterbegin', 'beforeend', 'afterend'];

export const classes = (...classNames) => classNames.filter(Boolean).join(' ');

/**
 * Creates a container div and inserts it relative to the target element.
 * @param {string} selector - CSS selector for the injection target
 * @param {string|string[]} [fallback] - fallback selector(s) if primary is not found (omit for no fallback)
 * @param {InsertPosition} [position='afterbegin'] - insertAdjacentElement position
 * @param {object} [options] - optional mount container attributes
 * @param {string} [options.className] - class name for the mount container
 * @param {string} [options.id] - id attribute for the mount container
 * @param {Record<string, string>} [options.dataset] - data-* attributes for the mount container
 * @param {Record<string, string>} [options.attributes] - arbitrary attributes for the mount container
 * @returns {HTMLElement|null} the created container, or null if no target found
 */
export const mountExperiment = (
	selector,
	fallback,
	position = 'afterbegin',
	options = {},
) => {
	if (typeof fallback === 'string' && POSITIONS.includes(fallback)) {
		position = fallback;
		fallback = undefined;
	}

	let target = document.querySelector(selector);

	if (!target && fallback !== undefined) {
		const fallbackSelectors = Array.isArray(fallback) ? fallback : [fallback];
		for (const fallbackSelector of fallbackSelectors) {
			target = document.querySelector(fallbackSelector);
			if (target) break;
		}
	}

	if (!target) return null;
	const container = document.createElement('div');

	const { className, id, dataset, attributes } = options;
	if (className) container.className = className;
	if (id) container.id = id;
	if (dataset) {
		for (const [key, value] of Object.entries(dataset)) {
			if (value != null) container.dataset[key] = String(value);
		}
	}
	if (attributes) {
		for (const [key, value] of Object.entries(attributes)) {
			if (value != null) container.setAttribute(key, String(value));
		}
	}

	target.insertAdjacentElement(position, container);
	return container;
};

/**
 * Fires an Adobe Analytics tracking event via the global `s` object.
 * @param {string} evar  - eVar variable name (e.g. 'eVar26')
 * @param {string} event - event variable name (e.g. 'event26')
 * @param {string} data  - descriptive label (e.g. 'experiment-name: v1 cta clicked')
 */
export const trackAAEvent = (evar, event, data) => {
	if (typeof s === 'undefined') return;
	s.linkTrackVars = `${evar}, events`;
	s.linkTrackEvents = `${event}`;
	s.events = `${event}`;
	s[evar] = data;
	s.tl(true, 'o', data);
};

/**
 * Polls until all given CSS selectors match at least one element each, then runs callback.
 * @param {string[]} selectors - array of CSS selector strings
 * @param {Function} callback  - invoked once every selector matches
 */
export const waitFor = (selectors, callback) => {
	if (!selectors.every((sel) => document.querySelector(sel))) {
		setTimeout(waitFor.bind(null, selectors, callback), 50);
	} else {
		callback();
	}
};

/**
 * Attaches a click tracking listener to an element inside an injected container.
 * Call this after render() — the element must already exist in the DOM.
 * @param {HTMLElement} container - the injected experiment container
 * @param {object}      options
 * @param {string}      options.label    - descriptive tracking label (required)
 * @param {string}      [options.selector='a'] - CSS selector relative to the container
 * @param {string}      [options.evar='eVar26'] - eVar variable name
 * @param {string}      [options.event='event26'] - event variable name
 */
export const setupTracking = (
	container,
	{ label, selector = 'a', evar = 'eVar26', event = 'event26' },
) => {
	const element = container.querySelector(selector);
	if (!element) return;
	element.addEventListener('click', () => {
		trackAAEvent(evar, event, label);
	});
};

/**
 * Waits for a CSS selector to appear in the DOM, then calls callback with the element.
 * Uses MutationObserver (event-driven) instead of polling.
 * @param {string}   selector               - CSS selector to watch for
 * @param {Function} callback               - called with the matched element
 * @param {object}   [options]
 * @param {boolean}  [options.subtree=false]  - observe all descendants (expensive — opt-in only)
 * @param {number}   [options.timeout=6000]   - auto-disconnect after ms to prevent memory leaks
 */
export const watchFor = (
	selector,
	callback,
	{ subtree = false, timeout = 6000 } = {},
) => {
	const existing = document.querySelector(selector);
	if (existing) {
		callback(existing);
		return;
	}
	const observer = new MutationObserver((_, obs) => {
		const element = document.querySelector(selector);
		if (element) {
			clearTimeout(timeoutId);
			obs.disconnect();
			callback(element);
		}
	});
	const timeoutId = setTimeout(() => observer.disconnect(), timeout);
	observer.observe(document.body, { childList: true, subtree });
};

/**
 * Creates a DOM element from an HTML string.
 * @param {string} htmlString
 * @returns {ChildNode|null}
 */
export const createElementFromHTML = (htmlString) => {
	const div = document.createElement('div');
	div.innerHTML = htmlString.trim();
	return div.firstChild;
};

export const setCookie = (cookieName, value, days) => {
	let expires = '';
	if (days) {
		const date = new Date();
		date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
		expires = `; expires=${date.toUTCString()}`;
	}
	document.cookie = `${cookieName}=${value || ''}${expires}; path=/`;
};

export const getCookie = (cookieName) => {
	const cookies = document.cookie.split(';');
	const cookie = cookies
		.map((item) => item.split('='))
		.find((item) => item[0].trim() === cookieName);
	return typeof cookie !== 'undefined' ? cookie[1] : null;
};

export const emergencyBrakeEnabled = () => {
	const name = getPackageName();
	const oneHour = 60 * 60 * 1000;
	let enabled = false;

	try {
		const config = JSON.parse(getEmergencyBrakeConfig());
		const { expireIn, disabledTests } = config;
		const expiresIn = Number.isInteger(expireIn) ? oneHour * expireIn : oneHour;
		const inTime =
			config.updatedAt && Date.now() - new Date(config.updatedAt) < expiresIn;
		const testIncluded =
			Array.isArray(disabledTests) && disabledTests.includes(name);
		enabled = Boolean(inTime && testIncluded);
	} catch {
		return enabled;
	}

	return enabled;
};
