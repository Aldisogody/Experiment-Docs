import { expect, test } from '@playwright/test';
import { translationByMarket } from '../src/config.js';
import { urlsConfig } from './config.js';
import { experimentContainer, setupPage, takeScreenshot } from './helpers.js';

for (const market of urlsConfig.markets) {
    test.describe(`ExperimentCard [${market.code}]`, () => {
        test('renders the experiment card with expected content', async ({ page }, testInfo) => {
            await setupPage(page, market, testInfo);
            const container = page.locator(experimentContainer);

            await expect(container).toContainText(translationByMarket.title);
            await expect(container).toContainText(translationByMarket.ctaText);
            await expect(container.locator('a')).toHaveAttribute('href', /\/smartphones\//);
            await expect(container).toContainText(/[\d.,]+/);

            const img = container.locator('img');
            await expect(img).toHaveAttribute('src', /galaxy-s25-ultra/);
            await expect(img).toHaveAttribute('alt', /Galaxy S25 Ultra/);
            await expect(img).toHaveAttribute('loading', 'lazy');

            await takeScreenshot(page, market.code, 'experiment-card', testInfo);
        });
    });
}
