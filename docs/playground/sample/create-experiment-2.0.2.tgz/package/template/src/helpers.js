import { MODEL_CODE_MAP, MULTI_MODEL_CODES_MAP, locale } from './config';

const lang = document.documentElement.lang;

export const modelCode = () => MODEL_CODE_MAP[locale] || MODEL_CODE_MAP.default;

const HYBRIS_MARKETS = ['ch', 'it', 'hu', 'es', 'ch_fr'];

const CURRENCY_MAP = {
    de: 'EUR',
    be: 'EUR',
    nl: 'EUR',
    be_fr: 'EUR',
    fr: 'EUR',
    es: 'EUR',
    uk: 'GBP',
    dk: 'DKK',
    se: 'SEK',
    no: 'NOK',
    fi: 'EUR',
    pt: 'EUR',
    pl: 'PLN',
    ua: 'UAH',
    ch: 'CHF',
    ch_fr: 'CHF',
    it: 'EUR',
    lv: 'EUR',
    lt: 'EUR',
    ee: 'EUR',
    hu: 'HUF',
    ro: 'RON',
};

const fetchProductCardRaw = async (model) => {
    const apiType = HYBRIS_MARKETS.includes(locale) ? 'hybris' : 'newhybris';
    const url = `https://searchapi.samsung.com/v6/front/b2c/product/card/detail/${apiType}?siteCode=${locale}&modelList=${model}&saleSkuYN=N&onlyRequestSkuYN=N&keySummaryYN=N&keySpecYN=N&quicklookYN=N&commonCodeYN=N`;

    const response = await fetch(url, {
        method: 'GET',
        credentials: 'omit',
        headers: {
            Accept: 'application/json',
        },
    });

    if (!response.ok) {
        throw new Error(`Samsung product card fetch failed (${response.status}) for model ${model}`);
    }

    const json = await response.json();
    const product = json?.response?.resultData?.productList?.[0]?.modelList;

    if (!product) {
        throw new Error('No product data returned');
    }

    return product.find((item) => item.modelCode === model) || product[0];
};

// TODO: Add/remove currencies as needed for your markets
export const formatPrice = (price) => {
    if (price == null) return '';

    const resolvedCurrency = CURRENCY_MAP[locale] || 'EUR';
    return new Intl.NumberFormat(lang, {
        style: 'currency',
        currency: resolvedCurrency,
        ...(locale === 'ua' && {
            minimumFractionDigits: 0,
            maximumFractionDigits: 0,
        }),
    }).format(price);
};

export const fetchProductCard = async () => {
    try {
        const data = await fetchProductCardRaw(modelCode());
        return { data, error: null };
    } catch (err) {
        return { data: null, error: err };
    }
};

export const fetchProductCards = async () => {
    const skus = MULTI_MODEL_CODES_MAP[locale] || MULTI_MODEL_CODES_MAP.default;
    if (!skus?.length) return [];
    const results = await Promise.allSettled(skus.map((sku) => fetchProductCardRaw(sku)));
    return results.map((result) =>
        result.status === 'fulfilled' ? { data: result.value, error: null } : { data: null, error: result.reason },
    );
};
