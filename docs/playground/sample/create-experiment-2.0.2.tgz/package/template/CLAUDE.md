# Template

Handlebars-powered project template for generated A/B experiment projects.

## Generated Project Stack

Vite (IIFE lib mode) + Preact + Sass (CSS Modules) + Biome (JS/JSX lint + format)

## Key Files

| File | Purpose |
|------|---------|
| `experiment.config.js.hbs` | Runtime config: globalObject, emergencyBrake, targetUrl |
| `src/config.js.hbs` | Experiment config: selectors, model codes, translations |
| `create-experiment/framework` | Runtime helpers: runScript, mountExperiment, setupTracking, trackAAEvent, waitFor, watchFor |
| `src/helpers.js` | Samsung product API fetch, price formatting, locale detection |
| `exp-build` | CLI command for per-variation IIFE bundles |
| `exp-start` | Production-mode watch wrapper command: `pnpm start 0` → `-e0` flag |
| `exp-live` | Package-owned Live Injection command; generated projects call it through `pnpm live` |
| `vite.config.js.hbs` | Shared Vite config: Preact plugin, aliases, IIFE output, CSS Modules |
| `biome.json.hbs` | Biome linter/formatter config (single quotes, 4-space, 120 width) |
| `package.json.hbs` | Dependencies, scripts (start, dev, build, lint) |
| `jsconfig.json.hbs` | JavaScript/JSX config for editor support |
| `playwright.config.js.hbs` | Playwright config (conditional, e2e only) |
| `e2e/smoke.spec.js` | Smoke test spec (conditional, e2e only) |
| `e2e/config.js.hbs` | E2E test config with market/URL (conditional, e2e only) |
| `e2e/helpers.js` | E2E test helpers (conditional, e2e only; minimal variant sourced from `template-minimal/e2e/`) |

## Variation Structure

Each variation lives in `src/js/vN/` with `index.jsx`:
1. `mountExperiment(selectors.primary, selectors.fallbacks, position)` — selects the primary target, then each fallback selector in order; creates container, inserts it; returns container or null
2. Guard: `if (!container) return`
3. Fetch product data via `helpers.js` (product-card boilerplate only)
4. `render(<ExperimentCard />)` into container
5. Setup click tracking — `setupTracking(container, { label })` AFTER render (element must exist)

## Import Aliases (in generated vite.config.js)

- `@src` → `src/`
- `@js` → `src/js/`
- `@components` → `src/components/`
- `@services` → `src/services/`
- `@helpers` → `src/helpers/`

## Generated Project Commands

```bash
pnpm start 0     # watch v1, copy production bundle without sourcemaps
pnpm dev         # watch all variations with development sourcemaps
pnpm build       # production IIFE bundles like dist/v1-index.jsx
pnpm lint        # biome check src
pnpm live        # package-owned exp-live opens targetUrl and injects watched variation
pnpm test:e2e    # run Playwright tests (only when e2e enabled)
```

## Conventions

- IIFE bundles — Preact is bundled, not external
- CSS Modules with camelCase convention
- Vite compiles Sass CSS Modules and minifies production CSS with esbuild; generated projects do not include Stylelint or cssnano dependencies
- Biome enforces: single quotes, 4-space indent, 120 char lines, no console (JS/JSX)
- Build (`exp-build`) runs Biome before bundling
- Package runtime helper `create-experiment/framework` uses global `s` object for Adobe Analytics tracking
- Use `@include mq()` instead of raw `min-width`/`max-width` media features in `*.module.scss` (a convention enforced by code review, not tooling)

## Minimal Boilerplate Variant (`template-minimal/`)

When `boilerplateType === 'minimal'`, the generator applies overlays from `template-minimal/src/` on top of this template:
- Replaces `ExperimentCard` with `ExperimentButton` component
- Replaces `src/config.js` and `src/js/v1/index.jsx` with minimal versions
- Does not generate `src/helpers.js`
- Does not generate per-variation `styles.module.scss`
- `e2e/smoke.spec.js` and `e2e/helpers.js` are sourced from `template-minimal/e2e/` instead
